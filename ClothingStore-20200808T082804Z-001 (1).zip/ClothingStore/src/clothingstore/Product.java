/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clothingstore;

/**
 *
 * @author USER
 */
public class Product {

    private String productCode;
    private String productName;
    private int quantity;
    private String[] colors = {"Red", "Black", "Blue", "Orange"};
    private String[] categories = {"Men", "Women", "Kid"};
    private String[] types = {"Dress", "Sunglasses", "Shoes"};
    private String color;
    private String category;
    private String type;
    private int price;

    public Product() {
    }

    public Product(String productCode, String productName, int quantity, String color, String category, String type, int price) {
        this.productCode = productCode;
        this.productName = productName;
        this.quantity = quantity;
        this.color = color;
        this.category = category;
        this.type = type;
        this.price = price;
    }

    public Product(String productCode, String productName, int price) {
        this.productCode = productCode;
        this.productName = productName;
        this.price = price;
    }

    public String[] getColors() {
        return colors;
    }

    public void setColors(String[] colors) {
        this.colors = colors;
    }

    public String[] getCategories() {
        return categories;
    }

    public void setCategories(String[] categories) {
        this.categories = categories;
    }

    public String[] getTypes() {
        return types;
    }

    public void setTypes(String[] types) {
        this.types = types;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

}
