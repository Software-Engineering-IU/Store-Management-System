/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clothingstore;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author USER
 */
public class Controller {

    private PreparedStatement ps;
    private ResultSet rs;
    private Product product;

    public Boolean addCustomer(Customer c) {
        boolean error = false;
        Connection conn = dbConnection();
        String sql = "INSERT INTO customer(id,cname,address,pcode,datee,cnic,phone,pname,pprice) Values(? ,? ,? , ? , ? , ? , ?,?,?)";
        try {
            ps = conn.prepareStatement("SELECT pquantity from product where pcode= ?");
            ps.setString(1, c.getProduct().getProductCode());
            rs = ps.executeQuery();
            int quantity = 0;
            while (rs.next()) {
                quantity = rs.getInt("pquantity");
            }
            if (quantity == 0) {
                error = true;
                return !error;
            }
            ps = conn.prepareStatement(sql);
            ps.setInt(1, c.getId());
            ps.setString(2, c.getName());
            ps.setString(3, c.getAddress());
            ps.setString(4, c.getProduct().getProductCode());
            ps.setString(5, c.getDate());
            ps.setString(6, c.getCnic());
            ps.setString(7, c.getPhone());
            ps.setString(8, c.getProduct().getProductName());
            ps.setInt(9, c.getProduct().getPrice());
            ps.executeUpdate();
            ps = conn.prepareStatement("SELECT pquantity from product where pcode= ?");
            ps.setString(1, c.getProduct().getProductCode());
            rs = ps.executeQuery();
            quantity = 0;
            while (rs.next()) {
                quantity = rs.getInt("pquantity");
            }
            ps = conn.prepareStatement("UPDATE product set pquantity = ? where pcode =? ");
            ps.setInt(1, quantity - 1);
            ps.setString(2, c.getProduct().getProductCode());
            ps.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            error = true;
        } finally {
            try {
                conn.close();
                ps.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        return !error;
    }

    public Boolean addProduct(Product p) {
        boolean error = false;
        Connection conn = dbConnection();
        String sql = "INSERT INTO product(pcode,pname,pquantity,pcolor,pcategory,ptype,pprice) Values(? ,? ,? , ? , ? , ? , ?)";
        try {
            ps = conn.prepareStatement(sql);
            ps.setString(1, p.getProductCode());
            ps.setString(2, p.getProductName());
            ps.setInt(3, p.getQuantity());
            ps.setString(4, p.getColor());
            ps.setString(5, p.getCategory());
            ps.setString(6, p.getType());
            ps.setInt(7, p.getPrice());
            ps.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            error = true;
        } finally {
            try {
                conn.close();
                ps.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        return !error;

    }

    public Product getProduct(String productCode) {
        product = null;
        Connection conn = dbConnection();
        try {
            ps = conn.prepareStatement("SELECT * FROM PRODUCT WHERE PCODE = ?");
            ps.setString(1, productCode);
            rs = ps.executeQuery();
            while (rs.next()) {
                product = new Product(rs.getString("pcode"), rs.getString("pname"), rs.getInt("pprice"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);

        } finally {
            try {
                conn.close();
                ps.close();
                rs.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        return product;
    }

    public static Connection dbConnection() {
        Connection conn = null;
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            String url = "jdbc:ucanaccess://C:\\Users\\USER\\Documents\\NetBeansProjects\\ClothingStore\\store.accdb";
            conn = DriverManager.getConnection(url);
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return conn;
    }
}
